
<?php

	
include 'koneksi.php';


function autoNumber($id, $table){
  $query = 'SELECT MAX(RIGHT('.$id.', 3)) as max_id FROM '.$table.' ORDER BY '.$id;
  $result = mysql_query($query);
  $data = mysql_fetch_array($result);
  $id_max = $data['max_id'];
  $sort_num = (int) substr($id_max, 1, 3);
  $sort_num++;
  $new_code = sprintf("%04s", $sort_num);
  return $new_code;
 }

?>

<div class="panel panel-default">
<div class="panel-heading">
        Tambah Data Pengadaan Barang
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" onsubmit="return validasi(this)" enctype="multipart/form-data">
                

			<div class="form-group">
	        <label> Nama Barang</label>
	        <select class="form-control"  name="id_brg" onchange="changeValue(this.value)">
			
	        	<option>== Pilih ==</option>
	            
                <?php 
					  $sql=$koneksi->query("SELECT * FROM barang ORDER BY id_brg");
					  $jsArray = "var prdName = new Array();\n";
                      $jsArray1 = "var prdName1 = new Array();\n";
					  while ($data=mysqli_fetch_array($sql)) {

					   echo '<option value="'.$data['id_brg'].'">'.$data['id_brg'].' - '.$data['nm_brg'].'</option> ';
					   $jsArray .= "prdName['" . $data['id_brg'] . "'] = {sat:'" . addslashes($data['sat']) . "'};\n";
                       $jsArray1 .= "prdName1['" . $data['id_brg'] . "'] = {hrg:'" . addslashes($data['hrg']) . "'};\n";
					  }
					 ?>
	        </select>
	      </div>
		  
				<div class="form-group">
                    <label>volume</label>
                    <input class="form-control" name="vol" id="vol" />
                    
                </div>

				<div class="form-group">
                    <label>satuan</label>
                    <input class="form-control" name="sat" id="sat" />
                    
                </div>
				
				<div class="form-group">
                    <label>harga</label>
                    <input class="form-control" name="hrg" id="hrg" />
                    
                </div>
				
				


                <div>
                    
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                </div>
         </div>

         </form>

         <script type="text/javascript">    
    <?php echo $jsArray; ?>
    <?php echo $jsArray1; ?>
    function changeValue(x){  
    document.getElementById('sat').value = prdName[x].sat; 
  
    document.getElementById('hrg').value = prdName1[x].hrg; 
    }; 
    </script>
    

      </div>
 </div>  
 </div>  
 </div>


 <?php

   
    
    $id_brg		     = $_POST ['id_brg'];
	$id_png			 = $_POST ['id_brg'];
	$vol			 = $_POST ['vol'];
	$sisa_vol			 = $_POST ['vol'];
	$sat			 = $_POST ['sat'];
	$hrg			 = $_POST ['hrg'];
	$tl_hrg			 = $_POST ['vol'] * $_POST ['hrg'];

  

	
	
	
    
	$simpan = $_POST ['simpan'];

	

    if ($simpan) {
        
        $sql = $koneksi->query("insert into pengadaan (id_png,id_brg,vol,sisa_vol,sat,hrg,tl_hrg)
		values('$id_png','$id_brg','$vol','$sisa_vol','$sat','$hrg','$tl_hrg')");

        if ($sql) {
            ?>
                <script type="text/javascript">
                    
                    alert ("Data Berhasil Disimpan");
                    window.location.href="?page=guna";

                </script>
            <?php
        }
    }

 ?>
                             
                             

