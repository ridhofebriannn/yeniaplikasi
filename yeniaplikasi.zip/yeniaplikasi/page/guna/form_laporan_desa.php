<div class="panel panel-default">
<div class="panel-heading">
		Cetak Laporan Data Desa
 </div> 
<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    
                                    <form method="POST" action="laporan/laporan.php"  >

                                  

                                        <div>
                                        	
                          
                                             <a href="./laporan/laporan.php" class="btn btn-default" target="blank" style="margin-top: 8px; margin-left: 5px;"> Cetak Semua</a>
                                        </div>
                                 </div>

                                 </form>
                              </div>
 </div>  
 </div>  
 </div>


 