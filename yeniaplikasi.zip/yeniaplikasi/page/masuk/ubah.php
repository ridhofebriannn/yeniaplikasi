<?php

	$id_brg = $_GET['id_brg'];

	$sql = $koneksi->query("select * from barang where id_brg='$id_brg'");

	$tampil = $sql->fetch_assoc();

	
?>

<div class="panel panel-default">
<div class="panel-heading">
		Ubah Data
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" >
                <div class="form-group">
                    <label>Nama Barang</label>
                    <input class="form-control" name="nm_brg" value="<?php echo $tampil['nm_brg'];?>" />
                    
                </div>

                <div class="form-group">
                    <label>Satuan</label>
                    <input class="form-control" name="sat" value="<?php echo $tampil['sat'];?>" />
                    
                </div>

                <div class="form-group">
                    <label>Kondisi Barang</label>
						<select name="kondisi_brg" class="form-control" required>
							<option value="">Pilih</option>
							<option selected value="Layak Digunakan">Layak Digunakan</option>
							<option value="Tidak Layak Digunakan">Tidak Layak Digunakan</option>
							<!-- <option value="petugas">Petugas</option> -->

						</select>
					</div>

                <div class="form-group">
                    <label>Harga</label>
                    <input class="form-control" name="hrg" value="<?php echo $tampil['hrg'];?>" />
                    
                </div>

                

                

                <div>
                	
                	<input type="submit" name="simpan" value="Ubah" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php

 
    $nm_brg = $_POST ['nm_brg'];
    $kondisi_brg = $_POST ['kondisi_brg'];
    $sat = $_POST ['sat'];
    $hrg = $_POST ['hrg'];
   

 	$simpan = $_POST ['simpan'];


 	if ($simpan) {
 		
 		$sql = $koneksi->query("update barang set nm_brg='$nm_brg', kondisi_brg='$kondisi_brg', sat='$sat', hrg='$hrg' where id_brg='$id_brg'");

 		if ($sql) {
 			?>
 				<script type="text/javascript">
 					
 					alert ("Ubah Data Barang Berhasil Disimpan");
 					window.location.href="?page=barang";

 				</script>
 			<?php
 		}
 	}

 ?>
                             
                             

