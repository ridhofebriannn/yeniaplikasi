<?php
	
	$id_desa = $_GET ['id_desa'];

	$koneksi->query("delete from desa where id_desa ='$id_desa'");

?>


<script type="text/javascript">
		window.location.href="?page=desa";
</script>