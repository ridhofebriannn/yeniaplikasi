<?php

	$id_png = $_GET['id_png'];

	$sql = $koneksi->query("select * from pengadaan inner join barang on pengadaan.id_brg=barang.id_brg where id_png='$id_png'");

	$tampil = $sql->fetch_assoc();
?>

<div class="panel panel-primary">
<div class="panel-heading">
		PENGAMBILAN ATK KANTOR
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" >
                <div class="form-group">
                    Nama Barang
                    <input class="form-control"  value="<?php echo $tampil['nm_brg'];?>" />
                    
                </div>
				
				<div >
                    Jumlah Pengadaan 
                    <input class="form-control" name="vol" value="<?php echo $tampil['vol'];?>" />
                    
                </div>
				<div >
                   Biaya Pengadaan Satuan
                    <input class="form-control" name="hrg" value="<?php echo $tampil['hrg'];?>" />
                    
                </div>
				
				
                <div class="form-group">
                    <label>Tambahkan Stok *(di isi)</label>
                    <input class="form-control" name="sisa_vol" id="sisa_vol" />
                    
                </div>

                

                

                <div>
                	
                	<input type="submit" name="simpan" value="Tambah Stok" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php

	
    
	$sisa_vol = $_POST ['sisa_vol'];
	$hrg = $_POST ['hrg'];
	
    $vol 		= $_POST ['sisa_vol'] + $_POST ['vol'];
	$tl_hrg 		= $_POST ['vol'] * $_POST ['hrg'];
   

 	$simpan = $_POST ['simpan'];


 	if ($simpan) {
 		
 		$sql = $koneksi->query("update pengadaan set  vol='$vol',sisa_vol='$sisa_vol' ,tl_hrg='$tl_hrg'
            where id_png='$id_png'");

 		if ($sql) {
 			?>
 				<script type="text/javascript">
 					
 					alert ("Ubah Berhasil Disimpan");
 					window.location.href="?page=guna";

 				</script>
 			<?php
 		}
 	}

 ?>
                             
                             

