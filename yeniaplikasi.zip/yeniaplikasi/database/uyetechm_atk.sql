-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 07, 2024 at 08:04 PM
-- Server version: 10.6.17-MariaDB-cll-lve
-- PHP Version: 8.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `atk`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_brg` varchar(5) NOT NULL,
  `nm_brg` varchar(22) NOT NULL,
  `sat` varchar(22) NOT NULL,
  `hrg` varchar(55) NOT NULL,
  `tgl_input` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_brg`, `nm_brg`, `sat`, `hrg`, `tgl_input`) VALUES
('0001', 'lemari kayu', 'buah', '125000', '2023-08-01 12:16:26'),
('0002', 'kursi lipat', 'pcs', '140000', '2023-11-11 12:52:55'),
('0003', 'pena', 'kotak', '3000', '2023-11-11 12:55:42'),
('23432', 'meja', 'pcs', '400000', '2024-04-22 05:00:23'),
('123', 'Komputer', '1 unit', '15000', '2024-05-04 06:21:17');

-- --------------------------------------------------------

--
-- Table structure for table `pengadaan`
--

CREATE TABLE `pengadaan` (
  `id_png` varchar(5) NOT NULL,
  `id_brg` varchar(6) NOT NULL,
  `vol` varchar(22) NOT NULL,
  `sisa_vol` varchar(22) NOT NULL,
  `jmlh_abl` varchar(22) NOT NULL,
  `vol_guna` varchar(5) NOT NULL,
  `sat` varchar(11) NOT NULL,
  `hrg` varchar(22) NOT NULL,
  `tl_hrg` varchar(22) NOT NULL,
  `biaya_png` varchar(33) NOT NULL,
  `tgl_input` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengadaan`
--

INSERT INTO `pengadaan` (`id_png`, `id_brg`, `vol`, `sisa_vol`, `jmlh_abl`, `vol_guna`, `sat`, `hrg`, `tl_hrg`, `biaya_png`, `tgl_input`) VALUES
('0001 ', '0001 ', '12', '5', '4', '7', 'rim', '125000', '792000', '625000', '2024-05-06 07:13:48'),
('0002 ', '0002 ', '25', '23', '', '', 'pcs', '200000', '132000', '', '2024-04-22 04:38:59'),
('0003 ', '0003 ', '4', '2', '2', '2', 'pcs', '3000', '6000', '0', '2024-05-06 07:15:08'),
('123 ', '123 ', '1', '1', '', '', 'buah', '12500000', '12500000', '', '2024-05-06 06:24:53');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(5) NOT NULL,
  `username` varchar(22) NOT NULL,
  `password` varchar(22) NOT NULL,
  `no_telp` varchar(13) NOT NULL,
  `level` enum('admin','mitra') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `no_telp`, `level`) VALUES
('0001', 'yeni', 'yeni', '1234456780', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_brg`);

--
-- Indexes for table `pengadaan`
--
ALTER TABLE `pengadaan`
  ADD PRIMARY KEY (`id_png`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
