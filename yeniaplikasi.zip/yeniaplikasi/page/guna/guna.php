<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                             DATA PENGADAAN BARANG
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div>
                            <a href="?page=guna&aksi=tambah" class="btn btn-danger" style="margin-top:  8px;"><i class="fa fa-plus"></i> Tambah Data Pengadaan Barang</a>
                            </div><br>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                         <tr style="background:gold;color:#333;">
                                            <th>No</th>
                                            <th>Nama Barang</th>
                                            <th>volume</th>
											
                                            <th>satuan</th>
                                            <th>harga</th>
											<th>total harga</th>
                                           
                                            
                                            <th width="19%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $no = 1;

                                        $sql = $koneksi->query("select * from pengadaan ");

                                        while ($data= $sql->fetch_assoc()) {

                                    ?>

                                    <tr>
                                        <td><?php echo $no++; ?></td>
										
										<td>
						
											<?php 
											$test = $data['id_brg'];
											// echo $test;
								
											$jdesa = $koneksi->query("SELECT  * FROM barang WHERE id_brg=$test");
											$jjdesa = $jdesa->fetch_assoc();
											echo $jjdesa['nm_brg'];
											?>
										</td>
										
                                        
                                        <td><?php echo $data['vol'];?></td>
										
                                        <td><?php echo $data['sat'];?></td>
                                        <td>Rp. <?php echo number_format ($data['hrg'])?></td>
										<td>Rp. <?php echo number_format ($data['tl_hrg'])?></td>
                                        
                                        <td>
                                            <a href="?page=guna&aksi=ubah1&id_png=<?php echo $data['id_png']; 
											?>" class="btn btn-success" ><i class="fa fa-edit"></i> Tambah Stok / volume</a>
											
                                            <a onclick="return confirm('Anda yakin ingin menghapus?')" href="?page=guna&aksi=hapus&id_png=
											<?php echo $data['id_png']; ?>" class="btn btn-danger" ><i class="fa fa-trash"></i> Hapus</a>

                                        </td>
                                    </tr>


                                    <?php  } ?>
                                    </tbody>

                                    </table>

                                  </div>
                        </div>
                     </div>
                   </div>
     </div>                           

     