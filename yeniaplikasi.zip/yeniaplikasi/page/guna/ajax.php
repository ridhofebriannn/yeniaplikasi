<?php
include "koneksi.php";
$barang = $koneksi->query("select * from barang where id_brg='$_GET[id_brg]'");
$barang1 = mysqli_fetch_array($barang);
$data_barang = array('sat'      =>  $barang1['sat'],
                    'hrg'     =>  $barang1['hrg'],);
 echo json_encode($data_barang);
 ?>