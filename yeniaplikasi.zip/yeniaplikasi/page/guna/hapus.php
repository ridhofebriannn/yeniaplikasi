<?php
	
	$id_png = $_GET ['id_png'];

	$koneksi->query("delete from pengadaan where id_png ='$id_png'");

?>


<script type="text/javascript">
		window.location.href="?page=guna";
</script>