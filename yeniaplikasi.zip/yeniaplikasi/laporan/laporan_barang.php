<?php
error_reporting(0);
$koneksi = new mysqli("localhost","root","","atk");
$content ='

<style type="text/css">
	
	.tabel{border-collapse: collapse;}
	.tabel th{padding: 8px 5px;  background-color:  #cccccc;  }
	.tabel td{padding: 8px 5px;     }
</style>


';


 $content .= '
<page>
<table border="0px" align="center">
<tr><td align="center"></td>

<td align="center"><h1>DAFTAR PESEDIAAN BARANG <br><br>UPTD BALAI LATIHAN KERJA</h1></td></tr></table>

<hr size="1px">
<br>

<table border="1px" class="tabel"  >
<tr><th colspan="6"><p align="center">Stok Awal</p></th><th colspan="4"><p align="center">Pengadaan Barang</p></th>
<th colspan="4"><p align="center">Penggunaan Barang</p></th><th colspan="4"><p align="center">Sisa Persediaan Barang </p></th></tr>

<tr>



<th rowspan>No </th>

<th>Nama Barang</th>
<th>Jml</th>
<th>Sat</th>
<th>Harga</th>
<th>Total Harga</th>
<th>Jml</th>
<th>Sat</th>
<th>Harga</th>
<th>Total Harga</th>

<th>Jml</th>
<th>Sat</th>
<th>Harga</th>
<th>Total Harga</th>

<th>Jml</th>
<th>Sat</th>
<th>Harga</th>
<th>Total Harga</th>

</tr>';

if (isset($_POST['cetak'])) {


	
	$tgl1 = $_POST['tanggal1'];
	$tgl2 = $_POST['tanggal2'];

	
		
	$no = 1;
	$sql = $koneksi->query("select * from pengadaan inner join barang on pengadaan.id_brg=barang.id_brg where tgl_input between '$tgl1' and '$tgl2' ");
	while ($tampil=$sql->fetch_assoc()) {
		
		$content .='
			<tr>
			<td align="center">'.$no++.'</td>
				<td align="left">'.$tampil['nm_brg'].'</td>
				<td align="center">-</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>
				<td align="center">-</td>
				
				<td align="left">'.$tampil['vol'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['tl_hrg'] .'</td>
				
				<td align="left">'.$tampil['vol_guna'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['tl_hrg'] .'</td>
				
				<td align="left">'.$tampil['sisa_vol'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['biaya_png'] .'</td>

		</tr>
		
		';
	
}
}else{

$no=1;

$sql = $koneksi->query("select * from pengadaan inner join barang on pengadaan.id_brg=barang.id_brg");
while ($tampil=$sql->fetch_assoc()) {
	$content .='
		<tr>
			<td align="center">'.$no++.'</td>
				<td align="left">'.$tampil['nm_brg'].'</td>
				<td align="center">-</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>
				<td align="center">-</td>
				
				<td align="left">'.$tampil['vol'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['tl_hrg'] .'</td>
				
				<td align="left">'.$tampil['vol_guna'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['tl_hrg'] .'</td>
				
				<td align="left">'.$tampil['sisa_vol'].'</td>
				<td align="left">'.$tampil['sat'].'</td>
				<td align="left">Rp. '.$tampil['hrg'].'</td>				
				<td align="left" > Rp. '.  $tampil['biaya_png'] .'</td>

		</tr>
		
	';
}
}


$content .='


</table>
<br><br><br><br>
<h4>Bandar Lampung,  -  -  <br><br><br><br>(..........................)</h4>
</page>';

require_once('../assets/html2pdf/html2pdf.class.php');
$html2pdf = new HTML2PDF('l','legal','fr');
$html2pdf->WriteHTML($content);
$html2pdf->Output('Laporan data apartur desa kab.rohul.pdf');
?>
