<?php

	
include 'koneksi.php';


function autoNumber($id, $table){
  $query = 'SELECT MAX(RIGHT('.$id.', 3)) as max_id FROM '.$table.' ORDER BY '.$id;
  $result = mysql_query($query);
  $data = mysql_fetch_array($result);
  $id_max = $data['max_id'];
  $sort_num = (int) substr($id_max, 1, 3);
  $sort_num++;
  $new_code = sprintf("%04s", $sort_num);
  return $new_code;
 }

?>

<div class="panel panel-default">
<div class="panel-heading">
        Tambah Data Pengadaan Barang
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" onsubmit="return validasi(this)" enctype="multipart/form-data">
                <div class="form-group">
                    <label>id_Pengadaan</label>
                   
                    <input name="id_png" type="text" class="form-control" 
					value="<?php echo autoNumber('id_png','pengadaan');?>" />
                </div>

			<div class="form-group">
	        <label> Nama Barang</label>
	        <select class="form-control"  name="id_brg">
			
	        	<option>== Pilih ==</option>
	            <?php
					$query = $koneksi->query("SELECT * FROM barang ORDER by id_brg");
					
					while ($id_brg=$query->fetch_assoc()) {
						echo "<option value='$id_brg[id_brg] $nm_brg[nm_brg]'>$id_brg[id_brg] - $id_brg[nm_brg] $nm_brg[nm_brg]</option>";
						
					}

	            ?>
	        </select>
	      </div>
		  
				<div class="form-group">
                    <label>volume</label>
                    <input class="form-control" name="vol" id="vol" />
                    
                </div>

				<div class="form-group">
                    <label>satuan</label>
                    <input class="form-control" name="sat" id="sat" />
                    
                </div>
				
				<div class="form-group">
                    <label>harga</label>
                    <input class="form-control" name="hrg" id="hrg" />
                    
                </div>
				
				


                <div>
                    
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php

   
    $id_png			 = $_POST ['id_png'];
    $id_brg		     = $_POST ['id_brg'];
	
	$vol			 = $_POST ['vol'];
	$sat			 = $_POST ['sat'];
	$hrg			 = $_POST ['hrg'];
	$tl_hrg			 = $_POST ['vol'] * $_POST ['hrg'];

  

	
	
	
    
	$simpan = $_POST ['simpan'];

	

    if ($simpan) {
        
        $sql = $koneksi->query("insert into pengadaan (id_png,id_brg,vol,sat,hrg,tl_hrg)
		values('$id_png','$id_brg','$vol','$sat','$hrg','$tl_hrg')");

        if ($sql) {
            ?>
                <script type="text/javascript">
                    
                    alert ("Data Berhasil Disimpan");
                    window.location.href="?page=guna";

                </script>
            <?php
        }
    }

 ?>
                             
                             

