<?php

	$id_desa = $_GET['id_desa'];

	$sql = $koneksi->query("select * from desa where id_desa='$id_desa'");

	$tampil = $sql->fetch_assoc();

	
?>

<div class="panel panel-default">
<div class="panel-heading">
		Ubah Data
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" >
                <div class="form-group">
                    <label>Nama Desa</label>
                    <input class="form-control" name="nm_desa" value="<?php echo $tampil['nm_desa'];?>" />
                    
                </div>

                <div class="form-group">
                    <label>Alamat</label>
                    <input class="form-control" name="alamat" value="<?php echo $tampil['alamat'];?>" />
                    
                </div>

                <div class="form-group">
                    <label>Kecamatan</label>
                    <input class="form-control" name="kecamatan" value="<?php echo $tampil['kecamatan'];?>" />
                    
                </div>

                <div class="form-group">
                    <label>Kode POS</label>
                    <input class="form-control" name="kd_pos" value="<?php echo $tampil['kd_pos'];?>" />
                    
                </div>

                

                <div>
                	
                	<input type="submit" name="simpan" value="Ubah" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php

 
    $nm_desa = $_POST ['nm_desa'];
    $alamat = $_POST ['alamat'];
    $kecamatan = $_POST ['kecamatan'];
    $kd_pos = $_POST ['kd_pos'];
   

 	$simpan = $_POST ['simpan'];


 	if ($simpan) {
 		
 		$sql = $koneksi->query("update desa set nm_desa='$nm_desa', alamat='$alamat', kecamatan='$kecamatan', kd_pos='$kd_pos'
            where id_desa='$id_desa'");

 		if ($sql) {
 			?>
 				<script type="text/javascript">
 					
 					alert ("Ubah Berhasil Disimpan");
 					window.location.href="?page=desa";

 				</script>
 			<?php
 		}
 	}

 ?>
                             
                             

