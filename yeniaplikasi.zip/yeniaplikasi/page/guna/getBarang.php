<?php
include "koneksi.php";
if($_REQUEST['brg_sat']) {
	$sql = "SELECT id_brg, nm_brg, sat, hrg FROM barang 
WHERE id_brg='".$_REQUEST['brg_sat']."'";
	$resultset = $koneksi -> query($sql);	
	$data = array();
	while( $rows = mysqli_fetch_assoc($resultset) ) {
		$data = $rows;
	}
	echo json_encode($data);
} else {
	echo 0;	
}
?>