<?php

	$id_png = $_GET['id_png'];

	$sql = $koneksi->query("select * from pengadaan inner join barang on pengadaan.id_brg=barang.id_brg where id_png='$id_png'");

	$tampil = $sql->fetch_assoc();
?>

<div class="panel panel-primary">
<div class="panel-heading">
		PENGAMBILAN ATK KANTOR
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" >
                <div class="form-group">
                    Nama Barang
                    <input class="form-control"  value="<?php echo $tampil['nm_brg'];?>" />
                    
                </div>
				
				<div class="form-group">
                    Stok Awal
                    <input class="form-control" name="vol" value="<?php echo $tampil['vol'];?>" />
                    
                </div>
				
				
				<div class="form-group">
                    sisa stok
                    <input class="form-control" name="sisa_vol" value="<?php echo $tampil['sisa_vol'];?>" />
                    
                </div>
				<div class="form-group">
                    harga satuan barang
                    <input class="form-control" name="hrg" value="<?php echo $tampil['hrg'];?>" />
                    
                </div>
				
				
				
                <div class="form-group">
                    <label>Jumlah Yang Diambil *(diisi)</label>
                    <input class="form-control" name="jmlh_abl" id="jmlh_abl" />
                    
                </div>

                

                

                <div>
                	
                	<input type="submit" name="simpan" value="AMBIL" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php

	
    
	$jmlh_abl = $_POST ['jmlh_abl'];
	$hrg		 = $_POST ['hrg'];
	$vol		 = $_POST ['vol'];


    $sisa_vol 		= $_POST ['sisa_vol'] - $_POST ['jmlh_abl'];
	
    $biaya_png		=  $_POST ['sisa_vol'] * $_POST ['hrg'];
	$vol_guna		=  $_POST ['vol'] - $_POST ['sisa_vol'];
	
	
	
	
	
 	$simpan = $_POST ['simpan'];


 	if ($simpan) {
 		
 		$sql = $koneksi->query("update pengadaan set  jmlh_abl='$jmlh_abl',hrg='$hrg'
		,vol='$vol'
		,sisa_vol='$sisa_vol'
		,biaya_png='$sisa_vol' * '$hrg' 
		,vol_guna='$vol' - '$sisa_vol'
        
		where id_png='$id_png'");

 		if ($sql) {
 			?>
 				<script type="text/javascript">
 					
 					alert ("Ubah Berhasil Disimpan");
 					window.location.href="?page=guna1";

 				</script>
 			<?php
 		}
 	}

 ?>
                             
                             

