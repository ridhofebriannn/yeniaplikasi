<?php
	
	$id_brg = $_GET ['id_brg'];

	$koneksi->query("delete from barang where id_brg ='$id_brg'");

?>


<script type="text/javascript">
		window.location.href="?page=barang";
</script>