<div class="panel panel-">
<div class="panel-heading">	
    <center><font size="+3" face="arial">
	<img src="gambar/lpg.png" style="width: 100px; height: 100px;"> 
	<center><font size="+3" face="arial" color="black">	
	SISTEM INVENTARIS BARANG MILIK DAERAH BERBASIS WEB DI UPTD BLK BANDAR LAMPUNG 
	</font></center>

</body>
<div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm" style="background-color: red;">
                                        <div class="media-body p-4 mt-2 text-center text-light">
                                            
											
                                    
                                    
                            