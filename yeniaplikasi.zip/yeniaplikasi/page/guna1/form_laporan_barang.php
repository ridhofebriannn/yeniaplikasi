<div class="panel panel-primary">
<div class="panel-heading">
		Cetak Laporan a
 </div> 
<div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    
                                    <form method="POST" action="laporan/laporan_aparatur.php"  >

                                        <div class="form-group">
                                            <label>Dari Tanggal </label>
                                            <input class="form-control" name="tanggal1" type="date"  />
                                            
                                        </div>

                                        <div class="form-group">
                                            <label>Sampai Tanggal </label>
                                            <input class="form-control" name="tanggal2" type="date"  />
                                            
                                        </div>


                                        <div>
                                        	
                                      
                                             <a href="./laporan/laporan_barang.php" class="btn btn-default" target="blank" style="margin-top: 8px; margin-left: 5px;"> Cetak </a>
                                        </div>
                                 </div>

                                 </form>
                              </div>
 </div>  
 </div>  
 </div>


 