
<?php 
include 'koneksi.php';

function autoNumber($id, $table){
  $query = 'SELECT MAX(RIGHT('.$id.', 4)) as max_id FROM '.$table.' ORDER BY '.$id;
  $result = mysql_query($query);
  $data = mysql_fetch_array($result);
  $id_max = $data['max_id'];
  $sort_num = (int) substr($id_max, 1, 4);
  $sort_num++;
  $new_code = sprintf("%04s", $sort_num);
  return $new_code;
 }

?>

<div class="panel panel-primary">
<div class="panel-heading">
        Tambah Data Barang
 </div> 
<div class="panel-body">
    <div class="row">
        <div class="col-md-12">
            
            <form method="POST" onsubmit="return validasi(this)" >
                <div class="form-group">
						<label>Id barang</label>
						<input name="id_brg" type="text" class="form-control" placeholder="Id barang .." 
						value="" />
					</div>
				<div class="form-group">
                    <label>Nama barang</label>
                    <input class="form-control" name="nm_brg" id="nm_brg" />
                    
                </div>

                <!-- <div class="form-group">
                    <label>Kondisi barang</label>
                    <input class="form-control" name="kondisi_brg" id="kondisi_brg" />
                    
                </div> -->

                <div class="form-group">
                    <label>Kondisi Barang</label>
						<select name="kondisi_brg" class="form-control" required>
							<option value="">Pilih</option>
							<option selected value="Layak Digunakan">Layak Digunakan</option>
							<option value="Tidak Layak Digunakan">Tidak Layak Digunakan</option>
							<!-- <option value="petugas">Petugas</option> -->

						</select>
					</div>

                <div class="form-group">
                    <label>satuan</label>
                    <input class="form-control" name="sat" id="sat" />
                    
                </div>
				<div class="form-group">
                    <label>harga</label>
                    <input class="form-control" name="hrg" id="hrg" />
                    
                </div>

                

                <div>
                    
                    <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                </div>
         </div>

         </form>
      </div>
 </div>  
 </div>  
 </div>


 <?php
	$id_brg 	= $_POST ['id_brg'];
    $nm_brg 	= $_POST ['nm_brg'];
    $kondisi_brg = $_POST ['kondisi_brg'];
    $sat		= $_POST ['sat'];
    $hrg		= $_POST ['hrg'];

    
	$simpan = $_POST ['simpan'];


    if ($simpan) {
        
        $sql = $koneksi->query("insert into barang (id_brg,nm_brg,kondisi_brg,sat, hrg)
		values('$id_brg', '$nm_brg','$kondisi_brg', '$sat', '$hrg')");

        if ($sql) {
            ?>
                <script type="text/javascript">
                    
                    alert ("Data Berhasil Disimpan");
                    window.location.href="?page=barang";

                </script>
            <?php
        }
    }

 ?>
                             
                             

