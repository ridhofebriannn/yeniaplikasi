$(document).ready(function(){  
	// code to get all records from table via select box
	$("#barangambil").change(function() {    
		var id = $(this).find(":selected").val();
		var dataString = 'brg_hrg='+ id;    
		$.ajax({
			url: 'getBarang.php',
			dataType: "json",
			data: dataString,  
			cache: false,
			success: function(barangData) {		
					$("#brg_sat").text(barangData.sat);
					$("#brg_hrg").text(barangData.hrg);
			} 
		});
 	}) 
});