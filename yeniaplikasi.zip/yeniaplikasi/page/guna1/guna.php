<div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                             DATA PENGGUNAAN ATK DAN SISA PERSEDIAAN ATK
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <br>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                         <tr style="background:gold;color:#333;">
                                            <th>No</th>
                                            <th>Nama Barang</th>
                                            <th>Sisa Stok</th>
                                            <th>satuan</th>
                                            <th>harga</th>
											<th>total harga</th>
                                           
                                            
                                            <th width="19%">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                        $no = 1;

                                        $sql = $koneksi->query("select * from pengadaan ");

                                        while ($data= $sql->fetch_assoc()) {

                                    ?>

                                    <tr>
                                        <td><?php echo $no++; ?></td>
										
										<td>
						
											<?php 
											$test = $data['id_brg'];
											// echo $test;
								
											$jdesa = $koneksi->query("SELECT  * FROM barang WHERE id_brg=$test");
											$jjdesa = $jdesa->fetch_assoc();
											echo $jjdesa['nm_brg'];
											?>
										</td>
										
                                        
                                        <td><?php echo $data['sisa_vol'];?></td>
                                        <td><?php echo $data['sat'];?></td>
										<td>Rp. <?php echo number_format ($data['hrg'])?></td>
										<td>Rp. <?php echo number_format ($data['tl_hrg'])?></td>
										
                                        
                                        <td>
                                            <a href="?page=guna1&aksi=ubah&id_png=<?php echo $data['id_png']; 
											?>" class="btn btn-success" ><i class="fa fa-edit"></i> Pengambil ATK</a>
											
                                            
                                        </td>
                                    </tr>


                                    <?php  } ?>
									
								
						
                                    </tbody>

                                    </table>

                                  </div>
                        </div>
                     </div>
                   </div>
     </div>                           

    <tr>

<



